package competition.cig.peterlawford.search_algs;


public interface GoalEvaluator {
	public boolean isGoal(Option o);
	public void setMario(float x, float y);
}
