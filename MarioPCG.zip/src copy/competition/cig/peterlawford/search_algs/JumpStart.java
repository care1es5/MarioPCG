package competition.cig.peterlawford.search_algs;

public class JumpStart extends PathInfo {
	final FurthestHighestPath best;
	public JumpStart(FurthestHighestPath p) {
		best = p;
	}
	
}
