package competition.cig.peterlawford.search_algs;

public class FurthestHighestPath extends PathInfo {

	public boolean fBumped;
	public boolean fBumpedUp;

}
