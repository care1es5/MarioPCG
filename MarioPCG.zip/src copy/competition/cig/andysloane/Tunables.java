package competition.cig.andysloane;


public class Tunables {
	public static float FactorA = 1f;
	public static float FactorB = 1f;
	public static float FactorC = 1f;
	//public static float GIncrement = 1.3f;
	public static float GIncrement = 1f;
	public static float DeadCost = 100000f;
	public static float FeetOnTheGroundBonus = 0f;
	public static int MaxBreadth = 60;
	public static float HurtCost = 5f;

	public static float PathFound = 0;
}
