f = open("mario_1.txt","rb")
lines = f.readlines()
new_map = ""
for line in lines:
    line = line.strip()
    for c in line:
        if c !="-":
            new_map += "#"
        else:
            new_map += c
    new_map += "\n"

new_map = new_map.strip()
with open("new_map.txt", "wb") as w:
    w.write(new_map)

"""
for i in range(10):
    for j in range(100):
        f.write("-")

    f.write("\n")

count = 0
for i in range(2):
    for j in range(100):
        f.write("#")
    
    if count:
        pass
    else:
        count += 1
        f.write("\n")
"""

f.close()
