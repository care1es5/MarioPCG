package ch.idsia.tools.tcp;

/**
 * Created by IntelliJ IDEA.
 * User: Sergey Karakovskiy, firstname_at_idsia_dot_ch
 * Date: Aug 7, 2009
 * Time: 12:38:41 PM
 * Package: ch.idsia.tools.tcp
 */
public enum TCP_MODE {
    SIMPLE_TCP,
    FAST_TCP
}
