package competition.icegic.peterlawford.simulator;

public class TheoreticWorld {

}
