package ch.idsia.ai.tasks;

/**
 * Created by IntelliJ IDEA.
 * User: julian
 * Date: May 26, 2009
 * Time: 12:21:15 PM
 */
public class ProgressPlusTimeLeftTask {

    // todo
}
